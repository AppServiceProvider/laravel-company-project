  <!-- Vendor JS Files -->
  <script src="{{asset('/frontEnd')}}/assets/vendor/jquery/jquery.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/php-email-form/validate.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/jquery-sticky/jquery.sticky.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/venobox/venobox.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="{{asset('/frontEnd')}}/assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="{{asset('/frontEnd')}}/assets/js/main.js"></script>

</body>

</html>