<?php echo $__env->make('frontEnd.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontEnd.include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('homeContent'); ?>

<?php echo $__env->make('frontEnd.include.footerTopUp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php laravel video\project-works\pullFromGithub\company\resources\views/frontEnd/index.blade.php ENDPATH**/ ?>