<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
  </head>
  <body>
    <div class="py-12">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="card-group"> 
                  <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <div class="col-md-4 mt-5">
                    <div class="card">
                      <img src="<?php echo e(asset($multi->image)); ?>" alt="">
                    </div>
                  </div> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <div class="card-header"> Multi Image </div>
              <div class="card-body">
                <form action="<?php echo e(route('store.image')); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <div class="form-group">
                    <label for="exampleInputEmail1">Multi Image</label>
                    <input type="file" name="image[]" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" multiple=""> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <button type="submit" class="btn btn-primary">Add Image</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html><?php /**PATH D:\php laravel video\project-works\pullFromGithub\company\resources\views/admin/multipic/index.blade.php ENDPATH**/ ?>